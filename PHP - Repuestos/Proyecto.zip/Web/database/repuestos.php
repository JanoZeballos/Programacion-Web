<?php

    if(file_exists("database/repuestos.json")):

        $contenidor = file_get_contents("database/repuestos.json");

        $imgr = json_decode($contenidor,true);

    else:

       $imgr = [];

        $imgr[] = [
            "id" => 1,
            "imagen" => "imagenes/2000351773293_2.jpg",
            "descripcion" => "Lorem Ipsum",
            "precio" => "1200",
            "cantidad" => "1"
        ];

        $imgr[] = [
            "id" => 2,
            "imagen" => "imagenes/2004191117262_2.jpg",
            "descripcion" => "Lorem Ipsum",
            "precio" => "1600",
            "cantidad" => "3"
        ];

        $imgr[] = [
            "id" => 3,
            "imagen" => "imagenes/descarga.jpg",
            "descripcion" => "Lorem Ipsum",
            "precio" => "2200",
            "cantidad" => "2"
        ];

    endif;