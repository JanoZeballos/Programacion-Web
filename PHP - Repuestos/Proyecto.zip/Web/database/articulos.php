<?php

    if(file_exists("database/articulos.json")):

        $contenido = file_get_contents("database/articulos.json");

        $img = json_decode($contenido,true);

    else:

       $img = [];

        $img[] = [
            "id" => 1,
            "nombre" => "Impresora Epson",
            "modelo" => "FX34",
            "precio" => "1200",
            "imagen" => "imagenes/2000351773293_2.jpg"
        ];

        $img[] = [
            "id" => 2,
            "nombre" => "Impresora Nova",
            "modelo" => "GT45",
            "precio" => "1600",
            "imagen" => "imagenes/2004191117262_2.jpg"
        ];

        $img[] = [
            "id" => 3,
            "nombre" => "Impresora Epson",
            "modelo" => "F3",
            "precio" => "2200",
            "imagen" => "imagenes/descarga.jpg"
        ];

    endif;