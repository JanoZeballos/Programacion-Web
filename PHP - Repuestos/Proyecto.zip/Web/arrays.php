<?php
    
   $navegador = [];

    $navegador[] = [
        "ruta" => "index.php?secciones=inicio",
        "nombre" => "inicio",
        "destino" => "INICIO"
    ];

    $navegador[] = [
        "ruta" => "index.php?secciones=listaarticulos",
        "nombre" => "listaarticulos",
        "destino" => "LISTA DE ARTICULOS"
    ];

    $navegador[] = [
        "ruta" => "index.php?secciones=agregararticulo",
        "nombre" => "agregararticulo",
        "destino" => "AGREGAR ARTICULO"
    ];
    
?>