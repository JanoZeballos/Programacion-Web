<?php

    function ultimoId($array){
        usort($array, function ($a, $b) {
            return $b['id'] - $a['id'];
        });

        $primerRegistro = $array[0];

        $ultimoId = $primerRegistro["id"];

        return $ultimoId;
    }

?>

<?php

    function verificaralta($id,$nombre,$modelo,$files,$precio){

    if(empty($id) || empty($nombre)):
    
        header("Location:index.php?secciones=agregararticulo&estado=vacio");
        die();

    endif;
        
        $info = [];

        $info["id"] = $id;
        $info["nombre"] = $nombre;
        $info["modelo"] = $modelo;
        $info["imagen"] = $files;
        $info["precio"] = $precio;
        
        return $info;
        
    }

?>

<?php

    function verificaraltarepuesto($id,$files,$descripcion,$precio,$cantidad){

    if(empty($id) || empty($descripcion)):
    
        header("Location:index.php?secciones=vistarepuesto&estado=vacio");
        die();

    endif;
        
    if(empty($files)):
        
        $inforepuesto = [];

        $inforepuesto["id"] = $id;
        $inforepuesto["descripcion"] = $descripcion;
        $inforepuesto["precio"] = $precio;
        $inforepuesto["cantidad"] = $cantidad;
        
        return $inforepuesto;
        
    else:
        
        $inforepuesto = [];

        $inforepuesto["id"] = $id;
        $inforepuesto["imagen"] = $files;
        $inforepuesto["descripcion"] = $descripcion;
        $inforepuesto["precio"] = $precio;
        $inforepuesto["cantidad"] = $cantidad;
        
        return $inforepuesto;
        
    endif;
        
    }

?>

<?php

    function eliminardir($dir){
        $result = false;
        if($handle = opendir("$dir")){
            $result = true;
            while ((($file=readdir($handle))!==false) && ($result)){
                if ($file!='.' && $file!='..'){
                    if (is_dir("$dir/$file")){
                        $result = eliminar_directorio("$dir/$file");
                    }else{
                        $result = unlink("$dir/$file");}}}
            closedir($handle);
            if($result){
                $result = rmdir($dir);
            }}
        return $result;
    }

?>