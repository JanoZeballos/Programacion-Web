<?php

    require_once("database/repuestos.php");
    require_once("funciones.php");
    
    if(empty($_POST["id"])):

        header("Location:index.php?secciones=listaarticulos&estado=noid");

    endif;

    foreach($imgr as $indice => $imagen):
        
        if($_POST["id"] == $imagen["id"]):
            $editar = $imagen;
            $posicion = $indice;
        
        endif;

    endforeach;

    $datos = [
        "id" =>  $_POST['id'],
        "imagen" => $_POST['imagen'],
        "descripcion" => $_POST['descripcion'],
        "precio" =>  $_POST['precio'],
        "cantidad" =>  $_POST['cantidad']
    ];

    $imgr[$posicion] = $datos;

    $arrayJSON = json_encode($imgr);

    file_put_contents("database/repuestos.json",$arrayJSON);

    header("Location:index.php?secciones=vistarepuesto&estado=editadacantidad&id=".$_POST['id']);
    die();
