<?php

    require_once("funciones.php");
    require_once("database/repuestos.php");

    $inforepuesto = verificaraltarepuesto($_POST["id"],$_FILES["imagen"],$_POST["descripcion"],$_POST["precio"],$_POST["cantidad"]);

    if(empty($inforepuesto["imagen"])):

        $imagen = [
            "id" => $inforepuesto['id'],
            "imagen" => null,
            "descripcion" => $inforepuesto['descripcion'],
            "precio" => $inforepuesto['precio'],
            "cantidad" => $inforepuesto['cantidad']
        ];

        $imgr[] = $imagen;

        $arrayJSON = json_encode($imgr);

        file_put_contents("database/repuestos.json",$arrayJSON);

        header("Location:index.php?secciones=vistarepuesto&estado=cargado&id=".$inforepuesto['id']);
        die();

    else:

        if($inforepuesto["imagen"]["type"] == "image/jpeg"):

            $formato = "jpg";

        elseif($inforepuesto["imagen"]["type"] == "image/png"):

            $formato = "png";

        elseif($inforepuesto["imagen"]["type"] == "image/gif"):

            $formato = "gif";

        else:

            header("Location:index.php?secciones=agregarrepuesto&estado=formato");
            die();

        endif;

    if(is_dir("imagenesrepuestos/".$inforepuesto['descripcion'])):
        
        header("Location:index.php?secciones=agregarrepuesto&estado=existe");
        die();

    endif;

    mkdir("imagenesrepuestos/".$inforepuesto['descripcion']);
    
    $nombreImagen = $inforepuesto["descripcion"];

    $altoCopia = 340;

    if($formato == "jpg"):

        $original = imagecreatefromjpeg($inforepuesto['imagen']["tmp_name"]);

        $anchoOriginal = imagesx($original);
        $altoOriginal = imagesy($original);

        $anchoCopia = $anchoOriginal * $altoCopia / $altoOriginal;

        $copia = imagecreatetruecolor($anchoCopia,$altoCopia);

        imagecopyresampled($copia,$original,0,0,0,0,$anchoCopia, $altoCopia, $anchoOriginal, $altoOriginal);

        imagejpeg($copia,"imagenesrepuestos/".$inforepuesto['descripcion']."/".$nombreImagen.".".$formato,100);
                   
            
    elseif($formato == "png"):

        $original = imagecreatefrompng($inforepuesto['imagen']["tmp_name"]);

        $anchoOriginal = imagesx($original);
        $altoOriginal = imagesy($original);

        $anchoCopia = $anchoOriginal * $altoCopia / $altoOriginal;

        $copia = imagecreatetruecolor($anchoCopia,$altoCopia);


        imagesavealpha($copia, true);
        imagealphablending($copia, false);
        imagecopyresampled($copia,$original,0,0,0,0,$anchoCopia, $altoCopia, $anchoOriginal, $altoOriginal);
        

        imagepng($copia,"imagenesrepuestos/".$inforepuesto['descripcion']."/".$nombreImagen.".".$formato,9);

    else:

        $original = imagecreatefromgif($inforepuesto['imagen']["tmp_name"]);

        $anchoOriginal = imagesx($original);
        $altoOriginal = imagesy($original);

        $anchoCopia = $anchoOriginal * $altoCopia / $altoOriginal;

        $copia = imagecreate($anchoCopia,$altoCopia);
        
        imagesavealpha($copia, true);
        imagealphablending($copia, false);
        imagecopyresampled($copia,$original,0,0,0,0,$anchoCopia, $altoCopia, $anchoOriginal, $altoOriginal);


        imagegif($copia,"imagenesrepuestos/".$nombreImagen.".".$formato,9);

    endif;

    file_put_contents("imagenesrepuestos/".$inforepuesto['descripcion']."/".$inforepuesto['descripcion'].".".$formato);
    
    $inforepuesto['id'] = $inforepuesto['id'];

    $imagen = [
        "id" => $inforepuesto['id'],
        "imagen" => "imagenesrepuestos/".$inforepuesto['descripcion']."/".$nombreImagen.".".$formato,
        "descripcion" => $inforepuesto['descripcion'],
        "precio" => $inforepuesto['precio'],
        "cantidad" => $inforepuesto['cantidad']
    ];

    $imgr[] = $imagen;
        
    $arrayJSON = json_encode($imgr);
    
    file_put_contents("database/repuestos.json",$arrayJSON);

    endif;

    header("Location:index.php?secciones=vistarepuesto&estado=cargado&id=".$inforepuesto['id']);