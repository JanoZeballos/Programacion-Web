<?php

    require_once("database/articulos.php");
    require_once("funciones.php");
    
    if(empty($_POST["id"])):

        header("Location:index.php?secciones=listaimpresoras");

    endif;


    foreach($img as $indice => $imagen):
        
        if($_POST["id"] == $imagen["id"]):
            $editar = $imagen;
            $posicion = $indice;
        
        endif;

    endforeach;
    
    if(!isset($editar)):

        header("Location:index.php?secciones=listaimpresoras");

    endif;

    $imagen = $editar["imagen"];
    $nombre = $editar["nombre"];

    eliminardir("imagenes/".$_POST["id"]);

    mkdir("imagenes/".$_POST["id"]);

    if(!empty($_POST["nombre"])):

        $nuevoNombre = $_POST["nombre"];

        rename("imagenes/".$editar["id"]."/".editar["nombre"],"imagenes/".$_POST["id"]."/".$_POST["nombre"]);

        $nombre = $nuevoNombre;

    endif;

    if(!empty($_FILES["imagen"])):

        if(isset($nuevoNombre)):
             if($_FILES["imagen"]["type"] == "image/jpeg"):

                $formato = "jpg";

            elseif($_FILES["imagen"]["type"] == "image/png"):
                $formato = "png";

            elseif($_FILES["imagen"]["type"] == "image/gif"):
                $formato = "gif";

            else:
                $formato = "png";
            endif;

            move_uploaded_file($_FILES["imagen"]["tmp_name"],"imagenes/".$editar['id']."/".$nuevoNombre.".".$formato);

            $imagen = "imagenes/".$editar['id']."/".$nuevoNombre.".".$formato;

        else:

            move_uploaded_file($_FILES["imagen"]["tmp_name"],$editar["imagen"]);

        endif;

    endif;

    $datos = [
      "id" => $editar["id"],
      "nombre" => $nombre,
      "modelo" => $_POST["modelo"],
      "imagen" => $imagen,
      "precio" => $_POST["precio"]
    ];

    $img[$posicion] = $datos;

    $arrayJSON = json_encode($img);

    file_put_contents("database/imagenes.json",$arrayJSON);

    header("Location:index.php?secciones=listaimpresoras&estado=editado");