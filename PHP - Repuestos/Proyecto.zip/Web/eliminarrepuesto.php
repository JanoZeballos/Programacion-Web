<?php

    require_once("database/repuestos.php");
    require_once("funciones.php");
    
    if(empty($_POST["id"])):

        header("Location:index.php?secciones=listaarticulos&estado=noid");

    endif;

    if($_POST["cantidad"] == 1):

    foreach($imgr as $indice => $imagen):
        
        if($_POST["id"] == $imagen["id"]):

            $eliminar = $imagen;
            $posicion = $indice;
        
        endif;

    endforeach;
    
    if(!isset($eliminar)):

        header("Location:index.php?secciones=vistarepuesto&estado=noencontrado&id=".$_POST['id']);

    endif;

    eliminardir("imagenesrepuestos/".$_POST["descripcion"]);

    unset($imgr[$posicion]);
        
    $arrayJSON = json_encode($imgr);

    file_put_contents("database/repuestos.json",$arrayJSON);
    
    header("Location:index.php?secciones=vistarepuesto&estado=eliminada&id=".$_POST['id']);

    else:

    foreach($imgr as $indice => $imagen):
        
        if($_POST["id"] == $imagen["id"]):
            $editar = $imagen;
            $posicion = $indice;
        
        endif;

    endforeach;

        $datos = [
            "id" =>  $_POST['id'],
            "imagen" => $_POST['imagen'],
            "descripcion" => $_POST['descripcion'],
            "precio" =>  $_POST['precio'],
            "cantidad" =>  $_POST['cantidad']-1
        ];

        $imgr[$posicion] = $datos;

        $arrayJSON = json_encode($imgr);

        file_put_contents("database/repuestos.json",$arrayJSON);

        header("Location:index.php?secciones=vistarepuesto&estado=eliminadacantidad&id=".$_POST['id']);
        die();



    endif;