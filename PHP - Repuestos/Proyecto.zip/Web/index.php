<!doctype html>
<html>
    <head>
        
        <?php
        
            require_once("arrays.php");
            require_once("database/articulos.php");
            require_once("database/repuestos.php");
            //require_once("global.php");
        
        ?>
        
       <link rel="icon" href="img/IconoMoonLight.jpg">
       <link rel="stylesheet" href="style.css">
       <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    </head>
    <body>
        
        <?php include "secciones/nav.php";?>
        
        <?php
            
            if(!empty($_GET["secciones"])){
            $secciones = $_GET["secciones"];
                
            if($secciones == "inicio"):
                require ("secciones/inicio.php");
                
            elseif($secciones == "agregararticulo"):
                require ("secciones/agregararticulo.php");
                
            elseif($secciones == "agregarrepuesto"):
                require ("secciones/agregarrepuesto.php");
        
            elseif($secciones == "listaarticulos"):
                require ("secciones/listaarticulos.php");
                
            elseif($secciones == "vistarepuesto"):    
                require ("secciones/vistarepuesto.php");
                
            elseif($secciones == "editarcantidadrepuesto"):    
                require ("secciones/editarcantidadrepuesto.php");
                
            else:
                
                require ("secciones/error404.php");
                
            endif;
            }else{
                require ("secciones/inicio.php");
            }
    
        ?>
        
        <?php include "secciones/footer.php";?>
        
    </body>
</html>