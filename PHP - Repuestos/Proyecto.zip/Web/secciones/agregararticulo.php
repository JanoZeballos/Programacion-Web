<?php

    if(!empty($_GET["estado"])):
        $estado = $_GET["estado"];

    if($estado == "vacio"):

        $mensaje = "El campo nombre es obligatorio";

    elseif($estado == "existe"):

        $mensaje = "El articulo ya está creado";

    elseif($estado == "formato"):

        $mensaje = "La imagen debe ser en formato JPG, PNG o GIF.";

    else:

        $mensaje = "No tocar la URL";

    endif;

?>

<center>
    <div class="alert alert-danger" role="alert">
      <?= $mensaje ?>
    </div>
</center>

<?php

    endif;

?>
<section class="background5">
    <center>
        <div class="centrar">
            <form method="POST" action="procesaralta.php" enctype="multipart/form-data">
                <div class="form-group">
                    <div class="text-dark">Ingrese el nombre del articulo</div>
                    <br />
                    <input type="text" id="nombre" placeholder="Nombre" name="nombre">
                </div>
                <br />
                <div class="form-group">
                    <div class="text-dark">Ingrese el modelo del articulo</div>
                    <br />
                    <input type="text" id="modelo" placeholder="Modelo" name="modelo">
                </div>
                <div class="form-group">
                    <div class="text-dark">Ingrese la imagen del articulo (opcional) </div>
                    <br />
                    <input type="file" accept="image/png, image/jpeg, image/gif" name="imagen"/> 
                </div>
                <br />
                <button type="submit" class="btn btn-primary w-25">Subir</button>
            </form>
        </div>
    </center>
</section>