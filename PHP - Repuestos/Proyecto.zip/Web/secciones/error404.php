<main class="error1">
<div id="falla">
    <h1> Ha ocurrido un error </h1>
</div>
</main>