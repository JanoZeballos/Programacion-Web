<?php
    
    if(!empty($_GET["estado"])):
        $estado = $_GET["estado"];
    
        if($estado == "cargado"):

            $mensaje = "El articulo fue cargado";

        elseif($estado == "editado"):

            $mensaje = "El articulo fue editado";

        elseif($estado == "noid"):

            $mensaje = "Esta id no existe";

        elseif($estado == "noencontrado"):

            $mensaje = "El articulo no fue encontrado";

        elseif($estado == "eliminada"):

            $mensaje = "El articulo fue eliminado";

        else:

            $mensaje = "No tocar la URL";

        endif;
    
?>

<br />
<center>
    <div class="alert alert-info" role="alert">
      <?= $mensaje ?>
    </div>
</center>

<?php

    endif;

?>

<table class="table table-hover">    
        <thead class="thead-dark">
        <tr>
            <th scope="col">Articulo</th>
            <th scope="col">Modelo</th>
            <th scope="col">Imagen</th>
            <th scope="col">Acciones</th>
        </tr>
        </thead>
        <tbody>
        <?php
           if(empty($img)):
        ?>
        <center>        
            <div class="alert alert-info" role="alert">
              Debe cargar datos para ver la visualizacion de la tabla
            </div>
        </center>            
        <?php
            else:
            foreach($img as $datos):
        ?>
        <tr>
        <td class="align-middle"><?= $datos["nombre"]; ?></td>
        <td class="align-middle"><?= $datos["modelo"]; ?></td>
        <td><img src="<?= $datos["imagen"]; ?>" alt="" width="100" height="100" class="img-thumbnail"></td>
        <td>
           <center> 
                <form action="procesar.php" method="post">
                    <input type="hidden" name="id" value="<?= $datos["id"]; ?>">
                    <div>
                        <a href="index.php?secciones=vistarepuesto&id=<?= $datos["id"]; ?>" class="btn btn-outline-info rounded-0 w-50" role="button" aria-pressed="true">Ver</a>
                    </div>
                </form>
                <form action="eliminar.php" method="post">
                    <br />
                    <input type="hidden" name="id" value="<?= $datos["id"]; ?>">
                    <button type="submit" class="btn btn-outline-danger rounded-0 w-50">Eliminar</button>
                </form> 
            </center>  
        </td>
        </tr>
        <?php
            endforeach;
            endif;
        ?>
        </tbody>
</table> 





