<?php

    if(!empty($_GET["estado"])):
        $estado = $_GET["estado"];

    if($estado == "vacio"):

        $mensaje = "El campo descripcion es obligatorio";

    elseif($estado == "existe"):

        $mensaje = "El repuesto ya está creado";

    elseif($estado == "formato"):

        $mensaje = "La imagen debe ser en formato JPG, PNG o GIF.";

    else:

        $mensaje = "No tocar la URL";

    endif;

?>

<center>
    <div class="alert alert-danger" role="alert">
      <?= $mensaje ?>
    </div>
</center>

<?php

    endif;

?>
<section class="background5">
    <center>
        <div class="centrar">
            <form method="POST" action="procesaraltarepuesto.php" enctype="multipart/form-data">
                <div class="form-group">
                    <div>Ingrese una descripcion para el repuesto</div>
                    <br />
                    <input type="text" id="descripcion" placeholder="Descripcion" name="descripcion">
                </div>
                <br />
                <div class="form-group">
                    <div>Ingrese el precio del respuesto</div>
                    <br />
                    <input type="text" id="precio" placeholder="Precio" name="precio">
                </div>
                <br />
                <div class="form-group">
                    <div>Ingrese la cantidad del respuesto</div>
                    <br />
                    <input type="text" value="1" id="cantidad" placeholder="Cantidad" name="cantidad">
                </div>
                <br />
                <div class="form-group">
                    <div>Ingrese la imagen del repuesto (opcional) </div>
                    <br />
                    <input type="file" accept="image/png, image/jpeg, image/gif" name="imagen"/> 
                </div>
                <input type="hidden" name="id" value="<?= $_GET["id"]; ?>">
                <button type="submit" class="btn btn-primary w-25">Subir</button>
            </form>
        </div>
    </center>
</section>