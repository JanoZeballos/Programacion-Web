<?php

    if(!empty($_GET["estado"])):
        $estado = $_GET["estado"];

    if($estado == "vacio"):

        $mensaje = "El campo descripcion es obligatorio";

    elseif($estado == "existe"):

        $mensaje = "El repuesto ya está creado";

    elseif($estado == "formato"):

        $mensaje = "La imagen debe ser en formato JPG, PNG o GIF.";

    else:

        $mensaje = "No tocar la URL";

    endif;

?>

<center>
    <div class="alert alert-danger" role="alert">
      <?= $mensaje ?>
    </div>
</center>

<?php

    endif;

?>
<section class="background7">
    <center>
        <div class="centrar">
            <form method="POST" action="procesareditarrepuesto.php" enctype="multipart/form-data">
                <?php
                    foreach($imgr as $modificar):
                    if($_GET["cantidad"] == $modificar["cantidad"]):
                ?>
                    <div class="text-dark">Editando la cantidad del repuesto</div>
                    <br />
                    <div class="text-dark">
                        <?= $modificar["descripcion"]; ?>
                    </div>
                    <br />
                    <div class="form-group">
                        <div class="text-dark">Ingrese la cantidad del respuesto</div>
                        <br />
                        <input type="text" value="<?= $_GET["cantidad"]; ?>" id="cantidad" placeholder="Cantidad" name="cantidad">
                    </div>
                    <input type="hidden" name="id" value="<?= $modificar["id"]; ?>">
                    <input type="hidden" name="imagen" value="<?= $modificar["imagen"]; ?>">
                    <input type="hidden" name="descripcion" value="<?= $modificar["descripcion"]; ?>">
                    <input type="hidden" name="precio" value="<?= $modificar["precio"]; ?>">
                <?php
                    endif;
                    endforeach;
                ?>
                <button type="submit" class="btn btn-primary w-25">Editar cantidad</button>
            </form>
        </div>
    </center>
</section>