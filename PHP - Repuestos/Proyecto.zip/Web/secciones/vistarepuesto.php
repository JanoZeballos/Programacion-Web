<?php
    
    if(empty($_GET["id"])):

        header("Location:index.php?secciones=listaarticulos");
        die();

    endif;

    foreach($img as $indice => $imagen):
        
        if($_GET["id"] == $imagen["id"]):

            $editar = $imagen;
            $posicion = $indice;
        
        endif;

    endforeach;
    
    if(!isset($editar)):

        header("Location:index.php?secciones=listaarticulos");
        die();

    endif;

?>
  
<?php
    
    if(!empty($_GET["estado"])):
        $estado = $_GET["estado"];

        if($estado == "cargado"):

            $mensaje = "El repuesto fue cargado";

        elseif($estado == "editado"):

            $mensaje = "El repuesto fue editado";

        elseif($estado == "noid"):

            $mensaje = "Esta id no existe";

        elseif($estado == "noencontrado"):

            $mensaje = "El repuesto no fue encontrado";

        elseif($estado == "eliminada"):

            $mensaje = "El repuesto fue eliminado";

        elseif($estado == "eliminadacantidad"):

            $mensaje = "Se elimino una cantidad de un repuesto (-1)";

        elseif($estado == "editadacantidad"):

            $mensaje = "La cantidad del repuesto fue editada";

        else:

            $mensaje = "No tocar la URL";

        endif;

?>

    <center>
        <div class="alert alert-info" role="alert">
          <?= $mensaje ?>
        </div>
    </center>

<?php

    endif;

?>
    
<section class="background6">
    <center>
        <div class="centrar">
             <div>
                 <h1 class="text-info">Vista repuestos</h1>
                 <br />
                 <div> 
                    <div>
                        <input type="text" id="nombre" name="nombre" value="<?= $editar["nombre"]; ?>" class="field left" readonly="readonly">
                    </div>
                    <br />
                    <div>
                        <input type="text" id="modelo" name="modelo" value="<?= $editar["modelo"]; ?>" class="field left" readonly="readonly">
                    </div>
                    <br />
                    <?php

                        if($editar["imagen"]):

                    ?>  
                    <div>

                        <img src="<?= $editar["imagen"]; ?>" alt="" width="150">

                    </div> 
                    <?php

                        endif;

                    ?>
                    <br />
                    <div>
                        <a href="index.php?secciones=agregarrepuesto&id=<?= $editar["id"]; ?>" class="btn btn-primary" role="button" aria-pressed="true">Agregar repuesto</a>
                    </div>
                 </div>
            </div>
        </div>
    </center>
</section>

<div class="alert alert-warning alert-dismissible fade show" role="alert">
  <strong>Tener en cuenta!</strong> El boton "Editar" solo se utiliza para modificar la cantidad del repuesto.
</div>

<center>
    <table class="table table-hover">    
            <thead class="thead-dark">
            <tr>
                <th scope="col">Imagen</th>
                <th scope="col">Descripcion</th>
                <th scope="col">Precio</th>
                <th scope="col">Cantidad</th>
                <th scope="col">Acciones</th>
            </tr>
            </thead>
            <tbody>
            <?php
                if(empty($imgr)):   
            ?>   
                <div class="alert alert-info" role="alert">
                  Debe cargar datos para ver la visualizacion de la tabla
                </div>         
            <?php 
                else:
                foreach($imgr as $base):
            ?>
            <tr>
            <?php
                if($base["id"] == $editar["id"]):  
            ?>
            <td><img src="<?= $base["imagen"]; ?>" alt="" width="100" class="img-thumbnail"></td>
            <td class="align-middle"><?= $base["descripcion"]; ?></td>
            <td class="align-middle">$<?= $base["precio"]; ?></td>
            <td class="align-middle"><?= $base["cantidad"]; ?></td>
            <td>
               <center>
                   <?php
                    if($base["cantidad"] > 5):
                   ?>
                    <br />
                    <div>
                        <a href="index.php?secciones=editarcantidadrepuesto&id=<?= $base["id"]; ?>&cantidad=<?= $base["cantidad"]; ?>" class="btn btn-info w-50" role="button" aria-pressed="true">Editar</a>
                    </div>
                   <?php
                    endif;
                   ?>
                    <form action="eliminarrepuesto.php" method="post">
                        <br />
                        <input type="hidden" name="id" value="<?= $base["id"]; ?>">
                        <input type="hidden" name="imagen" value="<?= $base["imagen"]; ?>">
                        <input type="hidden" name="descripcion" value="<?= $base["descripcion"]; ?>">
                        <input type="hidden" name="precio" value="<?= $base["precio"]; ?>">
                        <input type="hidden" name="cantidad" value="<?= $base["cantidad"]; ?>">
                        <button type="submit" class="btn btn-danger w-50" role="button" aria-pressed="true">Eliminar</button>
                    </form>
                </center>  
            </td>
            <?php
                else:
            ?>

            <?php
                endif;
            ?>
            </tr>
            </tbody>
            <?php
                endforeach;
                endif;
            ?>
    </table>
</center>