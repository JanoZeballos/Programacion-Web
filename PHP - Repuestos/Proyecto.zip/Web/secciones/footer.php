<footer class="derechos">
    <div class="footerContainer">
        Diseño Web 2018&copy; Jano Leonel Zeballos
    </div>
</footer>