<?php

    require_once("funciones.php");
    require_once("database/articulos.php");

    $ultID = ultimoId($img);

    $info = verificaralta($ultID+1,$_POST["nombre"],$_POST["modelo"],$_FILES["imagen"],$_POST["precio"]);

    if($info["imagen"] == 0):

        echo "asdasdas";
        die();

    endif;

    if(empty($info["imagen"])):

        $imagen = [
            "id" => $info['id'],
            "nombre" => $info['nombre'],
            "modelo" => $info['modelo'],
            "imagen" => null
        ];

        $img[] = $imagen;

        $arrayJSON = json_encode($img);

        file_put_contents("database/articulos.json",$arrayJSON);

        header("Location:index.php?secciones=listaarticulos&estado=cargado&articulo=".$info['nombre']);
        die();

    else:

        if($info["imagen"]["type"] == "image/jpeg"):

            $formato = "jpg";

        elseif($info["imagen"]["type"] == "image/png"):

            $formato = "png";

        elseif($info["imagen"]["type"] == "image/gif"):

            $formato = "gif";

        else:

            header("Location:index.php?secciones=agregararticulo&estado=formato");
            die();

        endif;

    if(is_dir("imagenes/".$info['id'])):
        
        header("Location:index.php?secciones=agregararticulo&estado=existe");
        die();

    endif;

    mkdir("imagenes/".$info['id']);
    
    $nombreImagen = $info["nombre"];

    $altoCopia = 340;

    if($formato == "jpg"):

        $original = imagecreatefromjpeg($info['imagen']["tmp_name"]);

        $anchoOriginal = imagesx($original);
        $altoOriginal = imagesy($original);

        $anchoCopia = $anchoOriginal * $altoCopia / $altoOriginal;

        $copia = imagecreatetruecolor($anchoCopia,$altoCopia);

        imagecopyresampled($copia,$original,0,0,0,0,$anchoCopia, $altoCopia, $anchoOriginal, $altoOriginal);

        imagejpeg($copia,"imagenes/".$info['id']."/".$nombreImagen.".".$formato,100);
                   
            
    elseif($formato == "png"):

        $original = imagecreatefrompng($info['imagen']["tmp_name"]);

        $anchoOriginal = imagesx($original);
        $altoOriginal = imagesy($original);

        $anchoCopia = $anchoOriginal * $altoCopia / $altoOriginal;

        $copia = imagecreatetruecolor($anchoCopia,$altoCopia);


        imagesavealpha($copia, true);
        imagealphablending($copia, false);
        imagecopyresampled($copia,$original,0,0,0,0,$anchoCopia, $altoCopia, $anchoOriginal, $altoOriginal);
        

        imagepng($copia,"imagenes/".$info['id']."/".$nombreImagen.".".$formato,9);

    else:

        $original = imagecreatefromgif($info['imagen']["tmp_name"]);

        $anchoOriginal = imagesx($original);
        $altoOriginal = imagesy($original);

        $anchoCopia = $anchoOriginal * $altoCopia / $altoOriginal;

        $copia = imagecreate($anchoCopia,$altoCopia);
        
        imagesavealpha($copia, true);
        imagealphablending($copia, false);
        imagecopyresampled($copia,$original,0,0,0,0,$anchoCopia, $altoCopia, $anchoOriginal, $altoOriginal);


        imagegif($copia,"imagenes/".$info['id']."/".$nombreImagen.".".$formato,9);

    endif;

    file_put_contents("imagenes/".$info['id']."/".$info['nombre'].".".$formato);
    
    $info['id'] = $info['id'];

    $imagen = [
        "id" => $info['id'],
        "nombre" => $info['nombre'],
        "modelo" => $info['modelo'],
        "imagen" => "imagenes/".$info['id']."/".$nombreImagen.".".$formato
    ];

    $img[] = $imagen;
        
    $arrayJSON = json_encode($img);
    
    file_put_contents("database/articulos.json",$arrayJSON);

    endif;

    header("Location:index.php?secciones=listaarticulos&estado=cargado&articulo=".$info['nombre']);