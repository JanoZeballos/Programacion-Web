<?php

    require_once("database/articulos.php");
    require_once("funciones.php");
    
    if(empty($_POST["id"])):

        header("Location:index.php?secciones=listaarticulos&estado=noid");

    endif;

    foreach($img as $indice => $imagen):
        
        if($_POST["id"] == $imagen["id"]):

            $eliminar = $imagen;
            $posicion = $indice;
        
        endif;

    endforeach;
    
    if(!isset($eliminar)):

        header("Location:index.php?secciones=listaarticulos&estado=noencontrado");

    endif;

    eliminardir("imagenes/".$_POST["id"]);

    unset($img[$posicion]);
        
    $arrayJSON = json_encode($img);

    file_put_contents("database/articulos.json",$arrayJSON);
    
    header("Location:index.php?secciones=listaarticulos&estado=eliminada");