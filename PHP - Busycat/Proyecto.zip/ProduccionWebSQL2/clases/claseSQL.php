<?php

class SQL{
    
//    private static $host = "localhost";
//    private static $username = "20181_equipo4";
//    private static $password = "908198f0259e98d8";
//    private static $database = "20181_equipo4";

    private static $host = "localhost";
    private static $username = "root";
    private static $password = "";
    private static $database = "web";

    public static function conectarMySQL(){
        
        static $link;
        
        if (empty($link)) {
            $link = mysqli_connect(SQL::$host,SQL::$username,SQL::$password,SQL::$database);
        
            if (!$link) {
                echo 'Error: ' . mysqli_connect_error();
            }
        }
        
        return $link;
    }

    public static function registroSQL($emailr,$passwordr){
        
        $link = SQL::conectarMySQL();

        $query = "INSERT INTO registro(EMAIL_USUARIO,PASSWORD_USUARIO)
                VALUES ('".$emailr."','".$passwordr."');";
        
        //echo $query;
        //die();
        
        $result = mysqli_query($link,$query);
        
        mysqli_close($link);
        
    }
    
    public function deleteMySQL($id){
        
        $link = SQL::conectarMySQL();
        
        //¿por qué razón necesitas "resetear" el auto_increment después de borrar algunos registros? Si la respuesta es para que no haya "brincos" y que la secuencia siempre esté completa, te puedo decir que es un terrible error Y NO DEBES HACERLO BAJO NINGUNA CIRCUNSTANCIA.

        //En realidad no tienes ningún beneficio en tener las secuencias completas, es exactamente lo mismo si hay brincos o no. Si por razones de "estética" o presentación necesitas numerar los registros, entonces hay otras formas de hacerlo sin necesidad de tenes que cambiar el valor del auto_increment...
        
        $query = "DELETE FROM registro WHERE ID_USUARIO = ".$id.";";

        $result = mysqli_query($link,$query);
        
        //mysqli_close($link);
        
    }
    
    public function deleteMySQLA($id){
        
        $link = SQL::conectarMySQL();
        
        $query = "DELETE FROM articulos WHERE ID_CUENTA = ".$id.";";

        $result = mysqli_query($link,$query);
        
        //mysqli_close($link);
        
    }
    
    public function deleteMySQLRA($id){
        
        $link = SQL::conectarMySQL();
        
        $query = "DELETE FROM art_registro WHERE ID_CUENTA = ".$id.";";

        $result = mysqli_query($link,$query);
        
        //mysqli_close($link);
        
    }
    
    public function selectMySQL(){
        
        $link = SQL::conectarMySQL();
        
        $query = 'SELECT ID_USUARIO,EMAIL_USUARIO,PASSWORD_USUARIO FROM registro;';
        
        $result = mysqli_query($link,$query);
        
        $respuesta = array();
        
        if ( 0 < mysqli_num_rows($result) ) {
           
            while ($row = mysqli_fetch_array($result)) {
                
                array_push($respuesta,array("id"=>$row["ID_USUARIO"],"email"=>$row["EMAIL_USUARIO"],"password"=>$row["PASSWORD_USUARIO"]));
        
            }
            
        } else {
        
            echo 'No hay resultados';
            
        }
        
        return json_encode($respuesta);
        
        mysqli_close($link);
    }
     
    
}