<?php


class Articulo{
    
    public function tablaarticulospublica($pagina,$contador,$limite){
        
        $ultimoid = self::buscarmaxID();
        
        if($pagina > 1){
           $paginaanterior = $pagina-1; 
        }else{
            $paginaanterior = 1;
        }
        
        if($pagina > 2){
          $contador += 10;
          $limite += 10;
        }
        
        $link = SQL::conectarMySQL();
        
        $query = 'SELECT ID_ARTICULO,ID_CUENTA,TITULO,TEXTO,IMAGEN FROM articulos;';
        
        $result = mysqli_query($link,$query);

        if ($result->num_rows > 0) {
            
        echo '<table class="tabla"><tr class="color2"><th>TITULO</th><th>IMAGEN</th><th>ACCION</th></tr>';
            
            while($row = $result->fetch_assoc()) {
                
                if($row["ID_ARTICULO"] > $contador && $row["ID_ARTICULO"] < $limite){
                
                echo '<tr class="color2"><td>'.$row["TITULO"].'</td><td><img src="'.$row["IMAGEN"].'" alt="" width="50"></td><td>
                <a href="index.php?modulos=visualizararticulo&id_art='.$row["ID_ARTICULO"].'" class="button">Ver</a>
                </td></tr>';
                    
                $contador++;
                    
                }
                
            }
            
        echo "</table>";
        
        /*
        echo "//Contador: $contador";
        echo "//Limite: $limite";
        echo "//Pagina: $pagina";
        echo "//Ultimo id: $ultimoid";
        */
              
        if($limite >= $ultimoid){
            $pagina;
        }else{
            $pagina++;
        }
            
        echo '
            <br />
            <center>
                <div class="button3">
                    <a href="index.php?modulos=mostrararticulos&pagina='.$pagina.'" class="button">Pag sig</a>
                </div>
            </center>';
        
        echo '
            <br />
            <center>
                <div class="button3">
                    <a href="index.php?modulos=mostrararticulos&pagina='.$paginaanterior.'" class="button">Pag ant</a>
                </div>
            </center>';
            
        } else {
            
        echo "No hay resultados";
            
        }
        
        //mysqli_close($link);
    }
    
    public function tablaarticulos(){
        
        $link = SQL::conectarMySQL();
        
        $datos = Cuenta::administrardatos();
        
        $query = 'SELECT ID_ARTICULO,ID_CUENTA,TITULO,TEXTO,IMAGEN FROM articulos;';
        
        $result = mysqli_query($link,$query);

        if ($result->num_rows > 0) {
            
        echo '<table class="tabla"><tr class="color1"><th>ID ARTICULO</th><th>ID USUARIO</th><th>TITULO</th><th>TEXTO</th><th>IMAGEN</th></tr>';
            
            while($row = $result->fetch_assoc()) {
                
                    if($row["ID_CUENTA"] == $datos->id){

                        echo '<tr class="color2"><td>'.$row["ID_ARTICULO"].'</td><td>'.$row["ID_CUENTA"].'</td><td>'.$row["TITULO"].'</td><td>'.$row["TEXTO"].'</td><td><img src="../'.$row["IMAGEN"].'" alt="" width="50"></td></tr>';

                    }      
            }
            
        echo "</table>";
            
        } else {
            
        echo "No hay resultados";
            
        }
        
        //mysqli_close($link);
        
    }
    
     //public function altaarticulo($id,$titulo,$texto,$imagen){
    
    public function altaarticulo($titulo,$texto,$rutaimagen){
        
        $datos = Cuenta::administrardatos();
        
        $id = $datos->id;
        
        $imagen = $rutaimagen;
        
        $link = SQL::conectarMySQL();

        $query = "INSERT INTO articulos(ID_CUENTA,TITULO,TEXTO,IMAGEN)
                VALUES ('".$id."','".$titulo."','".$texto."','".$imagen."');";
        
        //echo $query;
        //die();
        
        $result = mysqli_query($link,$query);
        
        //mysqli_close($link);   
        
    }
    
    public function registroarticuloalta(){
        
        $datos = Cuenta::administrardatos();
        
        $id = $datos->id;
        
        $id_art = self::buscarmaxID();
        
        $accion = "alta";
        
        $horario = date('Y-m-d H:m:s');
        
        $link = SQL::conectarMySQL();

        $query = "INSERT INTO art_registro(ID_ARTICULO,ID_CUENTA,ACCION,HORARIO)
                VALUES ('".$id_art."','".$id."','".$accion."','".$horario."');";
        
        //echo $query;
        //die();
        
        $result = mysqli_query($link,$query);
        
        //mysqli_close($link);   
        
    }

    public function verificaralta($titulo,$texto){

        if(empty($titulo) || empty($texto)):

            header("Location:index.php?secciones=altaarticulo&estado=vacio");
            die();

        endif;

        $info = [];

        $info["titulo"] = $titulo;
        $info["texto"] = $texto;

        return $info;

    } 
    
    public function buscarmaxID(){
        
        $maximo = 0;
        
        $link = SQL::conectarMySQL();
        
        $query = 'SELECT ID_ARTICULO FROM articulos;';
        
        $result = mysqli_query($link,$query);
        
        $respuesta = array();
        
        if ( 0 < mysqli_num_rows($result) ) {
           
            while($row = $result->fetch_assoc()) {
                
                if($row["ID_ARTICULO"] > $maximo){
                
                    $maximo = $row["ID_ARTICULO"];
                    
                } 
            }
            
        } else {
        
            echo 'No hay resultados';
            
        }
        
        return $maximo+1;
        
        mysqli_close($link);
        
        
    }
    
    public function tablamodifarticulos(){
        
        $link = SQL::conectarMySQL();
        
        $datos = Cuenta::administrardatos();
        
        $query = 'SELECT ID_ARTICULO,ID_CUENTA,TITULO,TEXTO,IMAGEN FROM articulos;';
        
        $result = mysqli_query($link,$query);

        if ($result->num_rows > 0) {
            
        echo '<table class="tabla"><tr class="color1"><th>ID ARTICULO</th><th>ID USUARIO</th><th>TITULO</th><th>TEXTO</th><th>IMAGEN</th><th>ACCION</th></tr>';
            
            while($row = $result->fetch_assoc()) {
                
                if($row["ID_CUENTA"] == $datos->id){
                
                echo '<tr class="color2"><td>'.$row["ID_ARTICULO"].'</td><td>'.$row["ID_CUENTA"].'</td><td>'.$row["TITULO"].'</td><td>'.$row["TEXTO"].'</td><td><img src="../'.$row["IMAGEN"].'" alt="" width="50"></td><td>
                <a href="index.php?secciones=editar&id_art='.$row["ID_ARTICULO"].'" class="button">Editar</a>
                </td></tr>';
                    
                } 
            }
            
        echo "</table>";
            
        } else {
            
        echo "No hay resultados";
            
        }
        
        //mysqli_close($link);
    }
    
    public function formmodifarticulos($id_art){
        
        $link = SQL::conectarMySQL();
        
        $datos = Cuenta::administrardatos();
        
        $query = 'SELECT ID_ARTICULO,ID_CUENTA,TITULO,TEXTO,IMAGEN FROM articulos;';
        
        $result = mysqli_query($link,$query);

        if ($result->num_rows > 0) {
            
            while($row = $result->fetch_assoc()) {
                
                if($row["ID_CUENTA"] == $datos->id && $row["ID_ARTICULO"] == $id_art ){
                
                echo '<form method="POST" action="secciones/procesarmodif.php" enctype="multipart/form-data">
                  <input type="hidden" name="id" value="'.$row["ID_ARTICULO"].'">
				  <div>
					<input type="text" id="nombre" name="titulo" value="'.$row["TITULO"].'">
				</div>
				<div>
				    <input type="file" accept="image/png, image/jpeg, image/gif" name="imagen"/> 
				</div>
                <div>
                    <img src="../'.$row["IMAGEN"].'" alt="" width="50">
                </div> 
				<br />
                <div>
                    <input type="text" id="texto" name="texto" value="'.$row["TEXTO"].'">
                </div>
				<button type="submit">Modificar</button>
			</form>';
                    
                } 
            }
            
        } else {
            
        echo "No hay resultados";
            
        }
        
        //mysqli_close($link);
    }
    
    public function visualizararticulo($id_art){
        
        $link = SQL::conectarMySQL();
        
        $query = 'SELECT ID_ARTICULO,ID_CUENTA,TITULO,TEXTO,IMAGEN FROM articulos;';
        
        $result = mysqli_query($link,$query);

        if ($result->num_rows > 0) {
            
            while($row = $result->fetch_assoc()) {
                
                if($row["ID_ARTICULO"] == $id_art ){
                
                echo '
                <center>
				    <div class="centrar4">
                        <h1 class="centrar3">'.$row["TITULO"].'</h1>
				    </div>
                    <div>
                        <img src="'.$row["IMAGEN"].'" alt="" width="360">
                    </div> 
                    <div class="centrar4">
                        <h3 class="centrar3">'.$row["TEXTO"].'</h3>
                    </div>
                </center>';  
                } 
            }
            
        } else {
            
        echo "No hay resultados";
            
        }
        
        //mysqli_close($link);
    }
    
    public function modificararticulo($id_art,$titulo,$texto,$imagen){
        
        $datos = Cuenta::administrardatos();
        
        $id = $datos->id;
        
        $link = SQL::conectarMySQL();
        
        $query = "UPDATE articulos
                  SET TITULO = '".$titulo."',TEXTO = '".$texto."',IMAGEN = '".$imagen."'
                  WHERE ID_ARTICULO = '".$id_art."' AND ID_CUENTA = '".$id."';";
        
        $result = mysqli_query($link,$query);
        
        mysqli_close($link);

    }
    
    public function registroarticulomodif($id_art){
        
        $datos = Cuenta::administrardatos();
        
        $id = $datos->id;
        
        $accion = "modif";
        
        $horario = date('Y-m-d H:m:s');
        
        $link = SQL::conectarMySQL();

        $query = "INSERT INTO art_registro(ID_ARTICULO,ID_CUENTA,ACCION,HORARIO)
                VALUES ('".$id_art."','".$id."','".$accion."','".$horario."');";
        
        //echo $query;
        //die();
        
        $result = mysqli_query($link,$query);
        
        //mysqli_close($link);   
        
    }
    
    public function eliminardirarticulo($dir){
        $result = false;
        if($handle = opendir("$dir")){
            $result = true;
            while ((($file=readdir($handle))!==false) && ($result)){
                if ($file!='.' && $file!='..'){
                    if (is_dir("$dir/$file")){
                        $result = eliminar_directorio("$dir/$file");
                    }else{
                        $result = unlink("$dir/$file");}}}
            closedir($handle);
            if($result){
                $result = rmdir($dir);
            }}
        return $result;
    }
    
}