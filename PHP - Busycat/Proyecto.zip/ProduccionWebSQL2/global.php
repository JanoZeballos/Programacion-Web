<?php

    date_default_timezone_set("America/Argentina/Buenos_Aires");
   
    error_reporting(-1);

    ini_set("display_errors","E_ALL");

?>