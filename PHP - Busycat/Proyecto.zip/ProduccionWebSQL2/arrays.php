<?php
    
   $navegador = [];

     $navegador[] = [
        "ruta" => "index.php?modulos=mostrararticulos",
        "nombre" => "mostrararticulos",
        "destino" => "ARTICULOS"
    ];

    $navegador[] = [
        "ruta" => "index.php?modulos=pagina",
        "nombre" => "inicio",
        "destino" => "INICIO"
    ];
    
?>


<?php

    $nav [1] [1] = "index.php";
    $nav [1] [2] = "../index.php";
    $nav [1] [3] = "index.php?secciones=altaarticulo";
    $nav [1] [4] = "index.php?modulo=inicio";
    $nav [1] [5] = "index.php?secciones=modifarticulo";
       
?>
