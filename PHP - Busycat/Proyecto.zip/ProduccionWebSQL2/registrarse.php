<?php

    require_once("clases/claseSQL.php");

    $emailr = $_POST["email"];
    $passwordr = password_hash($_POST["password"],PASSWORD_DEFAULT);

    SQL::conectarMySQL();

    SQL::registroSQL($emailr,$passwordr);
    
    header("Location:index.php?modulos=login&estado=registrado");
