<?php

    require_once("clases/claseSQL.php");

?>
<main class="objeto">    
    <div class="background">
        <div class="titulos">
        </div>
    </div>
</main>