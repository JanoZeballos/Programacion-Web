<?php

require_once("clases/clasearticulo.php");
require_once("clases/clasecuenta.php");
require_once("clases/claseSQL.php");

?>

    <div class="centrar">
        <?php
            Articulo::visualizararticulo($_GET["id_art"]);
        
            $pagina = $_GET["id_art"];
        ?>
        <br />
        <center>
            <div class="button3">
                <?php
                    if($pagina < Articulo::buscarmaxID()){
                       $pagina = $pagina+1;
                    }else if($pagina == Articulo::buscarmaxID()-1){
                       $pagina = Articulo::buscarmaxID()-1; 
                    }else{
                       $pagina = Articulo::buscarmaxID()+1;
                    }
                ?>
                <a href="index.php?modulos=visualizararticulo&id_art=<?= $pagina ?>" class="button">Pag sig</a>
            </div>
        </center>
        <br />
        <center>
            <div class="button3">
                <?php
                    if($pagina > 2){
                       $paginaanterior = $pagina-2; 
                    }else{
                        $paginaanterior = 1;
                    }
                ?>
                <a href="index.php?modulos=visualizararticulo&id_art=<?= $paginaanterior ?>" class="button">Pag ant</a>
            </div>
        </center>
    </div>