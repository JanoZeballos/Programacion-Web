<?php

    if(!empty($_GET["estado"])):
        $estado = $_GET["estado"];
    
        if($estado == "registrado"):

            $mensaje = "El usuario ha sido registrado";

        else:

            $mensaje = "No tocar la URL";

        endif;
?>
    <div>
        <p class="subido"> <?= $mensaje ?> </p>
    </div>
    
    <?php
    
        endif;
    
    ?>   
    
    <?php

    if(!empty($_GET["error"])):
        $estado = $_GET["error"];
    
        if($estado == 1):

            $mensaje = "El usuario no esta registrado";

        else:

            $mensaje = "No tocar la URL";

        endif;
    
    ?>
    
    <div>
        <p class="subido"> <?= $mensaje ?> </p>
    </div>
    
    <?php
    
        endif;
    
    ?>   

<div class="background16">
    <h3 class="cuentas">Introduzca alguna de estas cuentas o registrese(funciona):</h3>
    <div class="infocuenta">Cuenta admin: admin@web.com</div>
    <div class="infocuenta2">Contraseña: 1234</div>
    <div class="infocuenta">Email: alan.manganaro@davinci.edu.ar</div>
    <div class="infocuenta2">Contraseña: 1234</div>
    <div class="infocuenta">Email: gonzalo.montiel@davinci.edu.ar</div>
    <div class="infocuenta2">Contraseña: 1234</div>
    <div class="infocuenta">Email: marianela.ortubia@davinci.edu.ar</div>
    <div class="infocuenta2">Contraseña: 1234</div>
    <div class="enter">
    <h1 class="blanco">BIENVENIDO</h1>
        <span class="blanco">Ingresa a su cuenta</span>
            <form action="login.php" method="post">
                <div class="blanco">E-mail</div>
                <input type="text" class="form-control" placeholder="Introduzca su email" name="email"/>
                <div class="blanco">Password</div>
                <input type="password" class="form-control" placeholder="**********" name="password"/>
                <center>
                    <input type="submit" id="submit" value="Ingresar">
                </center>
            </form>     
    </div>
</div>