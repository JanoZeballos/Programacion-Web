<div class="background">
<?php

    if(!empty($_GET["estado"])):
        $estado = $_GET["estado"];

    if($estado == "modificado"):

        $mensaje = "El articulo fue modificado exitosamente";

    elseif($estado == "formato"):

        $mensaje = "La imagen debe ser en formato JPG, PNG o GIF.";

    else:

        $mensaje = "No cambiar la URL";

    endif;

?>

    <div>
        <p class="subido"> <?= $mensaje ?> </p>
    </div>

<?php

    endif;

?>
<table class="tabla">  
<caption id="titulo">
Articulos que puede modificar
</caption>
<section id="articulos">
</section>                
    <?php
        
        require_once("../clases/clasearticulo.php");
        require_once("../clases/clasecuenta.php");
        require_once("../clases/claseSQL.php");

        Articulo::tablamodifarticulos();
                
    ?>
</table>
</div>