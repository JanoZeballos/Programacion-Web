<?php

    if(!empty($_GET["estado"])):
        $estado = $_GET["estado"];

    if($estado == "vacio"):

        $mensaje = "El campo imagen y nombre son obligatorios";

    elseif($estado == "formato"):

        $mensaje = "La imagen debe ser en formato JPG, PNG o GIF.";

    elseif($estado == "cargado"):

        $mensaje = "El articulo fue cargado exitosamente";

    else:

        $mensaje = "No cambiar la URL";

    endif;

?>

    <div>
        <p class="subido"> <?= $mensaje ?> </p>
    </div>

<?php

    endif;

?>

<div class="centrar">
    <form method="POST" action="secciones/procesaralta.php" enctype="multipart/form-data">
        <div>
            <input type="text" id="id" placeholder="Ingrese titulo del articulo" name="titulo">
        </div>
        <div>
            <input type="file" name="imagen" class="form-control" accept="image/png, image/jpeg, image/gif">
        </div>
        <br />
        <div>
            <input type="text" id="texto" placeholder="Ingrese texto del articulo" name="texto">
        </div>
        <button type="submit">Subir</button>
    </form>
</div>