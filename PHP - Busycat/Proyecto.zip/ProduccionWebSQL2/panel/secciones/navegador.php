<nav>
    <ul class="barra">
      <?php
        
      if($_SESSION["usuario"]->id == 1){
          
      ?>
          <a class="navegacion" href=<?= $nav [1] [2]?>><li class="trabajos">VOLVER</li></a>
          <a class="navegacion" href="#borrarusuario"><li class="top">ELIMINAR CUENTA</li></a>
          <a class="navegacion" href=<?= $nav [1] [1]?>><li class="top" <?= isset($_GET["modulos"]) == "inicio" ?> >INICIO</li></a>
        
      <?php
        
      }else{

      ?>
        
      <a class="navegacion" href=<?= $nav [1] [2]?>><li class="trabajos">VOLVER</li></a>
      <a class="navegacion" href=<?= $nav [1] [5]?>><li class="top">MODIF ARTICULO</li></a> 
      <a class="navegacion" href=<?= $nav [1] [3]?>><li class="top">SUBIR ARTICULO</li></a> 
      <a class="navegacion" href=<?= $nav [1] [4]?>><li class="top">INICIO</li></a>       
        
      <?php
       
      }
    
      ?>
    </ul>
</nav>

