<?php
      $titulo="BusyCat";

      encabezado($titulo);


    function encabezado($titulo) {
        $encabezado="<title>$titulo</title>";
        echo $encabezado;
    }
?>