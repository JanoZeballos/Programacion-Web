<?php
    require_once("clases/claseusuario.php");
    require_once("clases/clasecuenta.php");
    require_once("clases/claseSQL.php");
    session_start();

    require_once("arrays.php");

    $emails = $_POST["email"];
    $passwords = $_POST["password"];

    if($emails == "admin@web.com" && $passwords = 1234){
        
        $posicion = Usuario::verificar($emails,$passwords);

        Usuario::administraradmin($posicion);
        
        header("Location:index.php");
        die();
        
    } else {
        
        $posicion = Usuario::verificar($emails,$passwords);

        $id = Usuario::administrarusuario($posicion);

        Cuenta::conexiones($id,$emails);

        header("Location:index.php");
        die();
        
    }

?>