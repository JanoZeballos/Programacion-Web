<?php
    
   $navegador = [];

    $navegador[] = [
        "ruta" => "index.php?modulos=pagina",
        "nombre" => "inicio",
        "destino" => "INICIO"
    ];
    
?>


<?php

    $nav [1] [1] = "index.php";
    $nav [1] [2] = "../index.php";
       
?>
