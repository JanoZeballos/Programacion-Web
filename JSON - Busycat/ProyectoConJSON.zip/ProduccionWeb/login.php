<?php
    require_once("panel/modulo/claseusuario.php");
    session_start();

    require_once("database/usuarios.php");
    require_once("funcion.php");
    require_once("arrays.php");

 

    foreach($usuarios as $pos => $usuario):
        
        if($usuario->email == $_POST["email"]):
            
            if(password_verify($_POST["password"],$usuario->password)):

                $posicion = $pos;

            endif;
        endif;
            
    endforeach;

    if(!isset($posicion)):
        header("Location:index.php?modulos=login&error=1");
        die();
    endif;

    
    $user = new Usuario();
    $user->id = $usuarios[$posicion]->id;
    $user->email = $usuarios[$posicion]->email;
    $user->password = $usuarios[$posicion]->password;
    $user->contador = $usuarios[$posicion]->contador + 1;

    $_SESSION["usuario"] = $user;

    $datos = [
      "id" => $usuarios[$posicion]->id,
      "email" => $usuarios[$posicion]->email,
      "contador" => $usuarios[$posicion]->contador + 1,
      "password" => $usuarios[$posicion]->password,
    ];

    $usuarios[$posicion] = $datos;

    $arrayJSON = json_encode($usuarios);

    file_put_contents("database/usuarios.json",$arrayJSON);


    header("Location:index.php");
    die();
?>
