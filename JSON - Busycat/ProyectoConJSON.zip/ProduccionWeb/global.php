<?php

    date_default_timezone_set("America/Argentina/Buenos_Aires");
   
    error_reporting(E_ALL);

    ini_set("display_errors","E_ALL");

?>