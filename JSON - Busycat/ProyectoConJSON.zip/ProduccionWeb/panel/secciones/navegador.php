<nav>
    <ul class="barra">
      <a class="navegacion" href=<?= $nav [1] [1]?>><li class="top" <?= isset($_GET["modulos"]) == "inicio" ?> >INICIO</li></a>
      <a class="navegacion" href=<?= $nav [1] [2]?>><li class="trabajos">VOLVER</li></a>
    </ul>
</nav>