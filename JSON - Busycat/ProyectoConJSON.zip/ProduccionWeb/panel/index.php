<!doctype html>
<html>
    <head>
        <?php
        require_once("modulo/claseusuario.php");
        session_start();
        
        if(!isset($_SESSION["usuario"])):
            header("Location:../index.php?estado=prohibido");
            die();
        endif;
 
        require_once("../arrays.php");
        require_once("../funciones.php");
        require_once("../database/usuarios.php");
        require_once("../database/cuentas.php");
        
        ?>
        
       <link rel="icon" href="../img/busycaticon.png">
       <link rel="stylesheet" href="stylee.css">
        
    </head>
    <body>
        
    <?php include "secciones/navegador.php";?>
    
    <?php
        
    if(!empty($_GET["secciones"])):
        $secciones = $_GET["secciones"];
        
    if($secciones == "listaimagenes"):
        require_once("secciones/listaimagenes.php");
        
    elseif($secciones == "editar"):    
        require_once("secciones/editar.php");
        
    elseif($secciones == "subirimagen"):    
        require_once("secciones/subirimagen.php");
                
    else:
                
        require_once("../modulos/error404.php");
                
    endif;
        
    else:
        
        include "modulo/inicio.php";
        
    endif;
        
    ?>
        
    <?php include "../modulos/footer.php";?>
        
    </body>
</html>