<main class="objeto">    
    <div class="background">
        <div class="titulos">
            <table class="tabla">  
                <caption id="titulo">
                 Panel de control
                </caption>    
                <thead>
                <tr class="color1">
                    <th>ID</th>
                    <th>Email</th>
                    <th>Fechas de logeos</th>
                    <th>Contador de logeos</th> 
                </tr>
                </thead>
                  <!--
                   <pre>
                    <?php
                        $fechaactual = getdate();
                      /*  
                        print_r($_SESSION["usuario"]);
                      */
                    ?>

                   </pre>
                   -->
                    <tr class="color2">
                        <td><?= $_SESSION["usuario"]->id; ?></td>
                        <td><?= $_SESSION["usuario"]->email; ?></td>
                        <td><?= "$fechaactual[weekday], $fechaactual[mday] de $fechaactual[month] de $fechaactual[year]"; ?></td>
                        <td><?= $_SESSION["usuario"]->contador; ?></td>
                    </tr>
                
            </table>
        </div>
    </div>
</main>