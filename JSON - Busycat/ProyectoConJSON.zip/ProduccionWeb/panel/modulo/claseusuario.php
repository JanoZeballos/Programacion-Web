<?php

class Usuario{

    public $id;
    public $email;
    public $contador;
    public $password;
    public $nombre;
    public $apellido;
    
    public function __construct($id = null,$email = null,$contador = null,$password = null){
        
        $this->id = $id;
        $this->email = $email;
        $this->contador = $contador;
        $this->password = $password;
        
    }
    
    
    public function login($usuario, $pass){}
    
    public function aumentarContador(){
        if($this->contador >= 1){
            $this->contador++;
        }else{
            $this->contador = 1;
        }
    }
    
    public function getFullName(){
        return $this->nombre . " " . $this->apellido;
    }
    
    public function ultimaConexion(){
        
    }

}