<?php
function ultimoId($array){
    usort($array, function ($a, $b) {
        return $b['id'] - $a['id'];
    });

    $primerRegistro = $array[0];

    $ultimoId = $primerRegistro["id"];

    return $ultimoId;
}
