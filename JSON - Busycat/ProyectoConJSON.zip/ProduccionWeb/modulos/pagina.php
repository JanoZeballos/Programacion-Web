<main class="objeto">    
    <div class="background">
        <div class="titulos">
            <h1><?php $_SESSION['count'] ?></h1>
        </div>
    </div>
</main>