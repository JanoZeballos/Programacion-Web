<nav>
    <?php 
        foreach($navegador as $navi):
    ?>
    <ul class="barra">
      <a class="navegacion" href="<?= "/ProduccionWeb/".$navi["ruta"] ; ?>"><li class="top" <?= isset($_GET["modulos"]) == $navi["nombre"]; ?> ><?= $navi["destino"]; ?></li></a>
    </ul>
    <?php
        endforeach;      
    ?>
    <?php
        if(!isset($_SESSION["usuario"])):
    ?>
        
        <li class="top2" <?= isset($_GET["modulos"]) && $_GET["modulos"] == "registro" ?> ><a class="navegacion" href="index.php?modulos=registrarse">REGISTRO</a></li>
        <li class="top2" <?= isset($_GET["modulos"]) && $_GET["modulos"] == "login" ?> ><a class="navegacion" href="index.php?modulos=login">LOGIN</a></li>

    <?php
        else:
    ?>         
        <li class="top2"><a class="navegacion" href="logout.php">LOGOUT</a></li>
        <li class="top2" <?= isset($_GET["modulos"]) && $_GET["modulos"] == "panel" ?> ><a class="navegacion" href="panel/index.php">PANEL</a></li>
    <?php
        endif;
    ?>
</nav>
