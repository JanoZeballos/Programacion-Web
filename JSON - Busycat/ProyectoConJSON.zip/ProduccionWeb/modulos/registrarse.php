<div class="background17">
    <div class="enter">
        <h1 class="blanco">BIENVENIDO</h1>
            <span class="blanco">Registrate</span>
       <form action="registrarse.php" method="POST">
           <div class="blanco">E-mail</div>
                <input type="text" name="email" class="form-control" placeholder="Ingrese un email"/>
            <div class="blanco">Password</div>
                <input type="password" name="password" class="form-control" placeholder="**********"/>
            <center>
                <input type="submit" id="submit" value="Registrarse">
            </center>
        </form>
    </div>
    </div>

        