<?php
    
    if(!empty($_GET["error"])):
        $estado = $_GET["error"];
    
    if($estado == 1):

        $mensaje = "El usuario no esta registrado";
    
    else:
    
        $mensaje = "No tocar la URL";
    
    endif;
    
    ?>
    
    <div>
        <p class="subido"> <?= $mensaje ?> </p>
    </div>
    
    <?php
    
    endif;
    
    ?>
<div class="background16">
    <div class="enter">
    <h1 class="blanco">BIENVENIDO</h1>
        <span class="blanco">Ingresa a su cuenta</span>
            <form action="login.php" method="post">
                <div class="blanco">E-mail</div>
                <input type="text" class="form-control" placeholder="Introdusca su email" name="email"/>
                <div class="blanco">Password</div>
                <input type="password" class="form-control" placeholder="**********" name="password"/>
                <center>
                    <input type="submit" id="submit" value="Ingresar">
                </center>
            </form>     
    </div>
</div>