<?php

    if(file_exists("database/cuentas.json")):
        $contenido = file_get_contents("database/cuentas.json");

        $cuentas = json_decode($contenido,true);
    else:

        $cuentas = [];

        $cuentas[] = [
            "id" => 1,
            "email" => "janozeballos@hotmail.com",
            "contador" => 0,
            "password" => password_hash("1234",PASSWORD_DEFAULT)
        ];

        $cuentas[] = [
            "id" => 2,
            "email" => "jano.zeballos@davinci.edu.ar",
            "contador" => 0,
            "password" => password_hash("1234",PASSWORD_DEFAULT)
        ];

        $cuentas[] = [
            "id" => 3,
            "email" => "admin@gmail.com",
            "contador" => 0,
            "password" => password_hash("1234",PASSWORD_DEFAULT)
        ];

       
    endif;

