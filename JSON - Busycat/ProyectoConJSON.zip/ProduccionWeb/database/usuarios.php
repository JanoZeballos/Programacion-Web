<?php

    if(file_exists("database/usuarios.json")):
        $contenido = file_get_contents("database/usuarios.json");

        $usuarios = json_decode($contenido,false);
    elseif(file_exists("../database/usuarios.json")):
        $contenido = file_get_contents("../database/usuarios.json");

        $usuarios = json_decode($contenido,false);
    else:

        $usuarios = [];

        $usuarios[] = [
            "id" => 1,
            "email" => "janozeballos@hotmail.com",
            "contador" => 0,
            "password" => password_hash("1234",PASSWORD_DEFAULT)
        ];

        $usuarios[] = [
            "id" => 2,
            "email" => "jano.zeballos@davinci.edu.ar",
            "contador" => 0,
            "password" => password_hash("1234",PASSWORD_DEFAULT)
        ];

        $usuarios[] = [
            "id" => 3,
            "email" => "admin@gmail.com",
            "contador" => 0,
            "password" => password_hash("1234",PASSWORD_DEFAULT)
        ];

       
    endif;



