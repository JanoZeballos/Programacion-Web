<?php

    require_once("database/usuarios.php");
    require_once("funcion.php");

   

    $datos = [
        "id" => ultimoId($usuarios) + 1,
        "email" => $_POST["email"],
        "password" => password_hash($_POST["password"],PASSWORD_DEFAULT)
    ];

    $usuarios[] = $datos;

    $usJson = json_encode($usuarios);

    file_put_contents("database/usuarios.json",$usJson);

    
    header("Location:index.php?modulos=login&estado=registrado");
