<!doctype html>
<html>
    <head>
        
        <?php
        
        session_start();
        require_once("arrays.php");
        require_once("funciones.php");
        require_once("global.php");
        
        ?>
        
       <link rel="icon" href="img/busycaticon.png">
       <link rel="stylesheet" href="style.css">
    </head>
    <body>
        
        <?php include "modulos/nav.php";?>
        
        <?php
            
            if(!empty($_GET["modulos"])){
            $modulos = $_GET["modulos"];
                
            if($modulos == "pagina"):
                require ("modulos/pagina.php");
            
            elseif($modulos == "login"):
                require ("modulos/login.php");
                
            elseif($modulos == "registrarse"):
                require ("modulos/registrarse.php");
                
            elseif($modulos == "panel"):
                require ("modulos/panel.php");
                
            else:
                
                require ("modulos/error404.php");
                
            endif;
            }else{
                require ("modulos/pagina.php");
            }
    
        ?>
        
        <?php include "modulos/footer.php";?>
        
    </body>
</html>